from django.shortcuts import render
from app1.models import Blog
# Create your views here.
def index(request):
    posts = Blog.objects.all
    post = {'posts': posts,}
    return render(request, 'home.html', post)


def details(request, pk):
    posts = Blog.objects.get(pk=pk)
    pt = {'posts': posts,}
    return render(request, 'details.html', pt)